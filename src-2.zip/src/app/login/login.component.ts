import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  validateLogin(loginData: NgForm){
    let username = loginData.value.uname;
    let password = loginData.value.pswd;

    alert(username);
    alert(password);
    alert(loginData.value.remember)

    if( username =="Dell" && password == "dellindia") {
      alert("Login Success")
    } else {
      alert("Enter valid credentials")
    }
    
  }

}
